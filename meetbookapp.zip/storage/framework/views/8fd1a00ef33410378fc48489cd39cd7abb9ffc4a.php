<!DOCTYPE html>
<html>

<head>
    <!-- Basic Page Info -->
    <meta charset="utf-8" />
    <title><?php echo e(config('app.name')); ?> - Zekindo</title>

    <!-- Site favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="vendors/images/apple-touch-icon.png" />
    <link rel="icon" type="image/png" sizes="32x32" href="vendors/images/favicon-32x32.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="vendors/images/favicon-16x16.png" />

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

    <?php echo $__env->make('front.layouts.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    
    
    
    <?php echo $__env->make('front.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php if(auth()->guard()->check()): ?>
        
        <?php echo $__env->make('front.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    <?php endif; ?>
    <div class="mobile-menu-overlay"></div>

    
    <?php echo $__env->yieldContent('content'); ?>

    <div class="main-container">
        <div class="xs-pd-20-10 pd-ltr-20">
            <div class="footer-wrap pd-20 mb-20 card-box">
                Meeting Room Book App
            </div>
        </div>
    </div>
    
    <?php echo $__env->make('front.layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html>
<?php /**PATH /home/vagrant/meetbookapp/resources/views/front/layouts/app.blade.php ENDPATH**/ ?>