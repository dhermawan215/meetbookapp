
<?php $__env->startSection('content'); ?>
    <div class="main-container">
        <div class="xs-pd-20-10 pd-ltr-20">
            <div class="row pb-10">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="min-heigth-200px">
                        <div class="page-header">
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <div class="title">
                                        <h4>Agenda</h4>
                                    </div>
                                    <nav aria-label="breadcrumb" role="navigation">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><i class="bi bi-house"></i>
                                                <a href="<?php echo e(route('app.dashboard')); ?>">Home</a>
                                            </li>
                                            <li class="breadcrumb-item">
                                                <a href="<?php echo e(route('agenda.index')); ?>">Agenda</a>
                                            </li>
                                            <li class="breadcrumb-item active">
                                                Detail Agenda
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row pb-10">
                <div class="col-lg-12 col-md-12 col-sm-12 mt-1">
                    <div class="pd-20 card-box mb-30">
                        <div class="clearfix mb-2">
                            <div class="pull-left">
                                <h4 class="text-blue h4">Detail Meeting Agenda No: <?php echo e($data->book_no); ?> </h4>
                            </div>
                        </div>
                        <form>
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">Activity</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" type="text" id="activity" disabled
                                        value="<?php echo e($data->activity); ?>" />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">Topic</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" type="text" disabled value="<?php echo e($data->topic); ?>" />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">Room</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" type="text" disabled
                                        value="<?php echo e($data->rooms->nama_ruang); ?>" />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">User</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" type="text" disabled value="<?php echo e($data->user->name); ?>" />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">Start Date</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" type="text" disabled value="<?php echo e($data->start_date); ?>" />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">End Date</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" type="text" disabled value="<?php echo e($data->end_date); ?>" />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">Start Time</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" type="text" disabled value="<?php echo e($data->start_time); ?>" />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">End Time</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" type="text" disabled value="<?php echo e($data->end_time); ?>" />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">Participants</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" type="text" disabled
                                        value="<?php echo e($data->participants ?? 'no data available'); ?>" />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">Notes</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" type="text" disabled
                                        value="<?php echo e($data->note ?? 'no data available'); ?>" />
                                </div>
                            </div>
                            <div class="">
                                <a href="<?php echo e(route('agenda.index')); ?>" class="btn btn-outline-danger"> <i
                                        class="bi bi-arrow-left-circle"></i>Back</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/meetbookapp/resources/views/front/pages/agenda/details.blade.php ENDPATH**/ ?>