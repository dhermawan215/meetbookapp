<a href="/">
    
    <img src="https://digsys.zekindo.co.id/vendors/images/ZEKINDO%20COMPANIES.png" alt="" height="250px"
        width="200px">
</a>
<?php /**PATH /home/vagrant/meetbookapp/resources/views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>