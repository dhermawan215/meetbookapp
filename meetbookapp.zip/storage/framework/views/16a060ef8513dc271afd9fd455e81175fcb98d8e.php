
<?php $__env->startSection('content'); ?>
    <div class="main-container">
        <div class="xs-pd-20-10 pd-ltr-20">
            <div class="row pb-10">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="min-heigth-200px">
                        <div class="page-header">
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <div class="title">
                                        <h4>Agenda</h4>
                                    </div>
                                    <nav aria-label="breadcrumb" role="navigation">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><i class="bi bi-house"></i>
                                                <a href="<?php echo e(route('app.dashboard')); ?>">Home</a>
                                            </li>
                                            <li class="breadcrumb-item">
                                                <a href="<?php echo e(route('agenda.index')); ?>">Agenda</a>
                                            </li>
                                            <li class="breadcrumb-item active">
                                                Edit Agenda
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php if($errors->any()): ?>
                <div class="row pb-10">
                    <div class="col-12">
                        <div class="alert alert-danger" role="alert">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="row pb-10">
                <div class="col-lg-12 col-md-12 col-sm-12 mt-1">
                    <div class="pd-20 card-box mb-30">
                        <div class="clearfix mb-2">
                            <div class="pull-left">
                                <h4 class="text-blue h4">Edit Your Meeting Agenda</h4>

                            </div>
                        </div>
                        <form action="<?php echo e(route('agenda.update', $data->id)); ?>" method="post">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">Book No</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" type="text" name="book_no" id="book_no"
                                        value="<?php echo e($data->book_no); ?>" disabled />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">Activity</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" type="text" placeholder="Activity of meeting"
                                        name="activity" id="activity" value="<?php echo e(old('activity') ?? $data->activity); ?>" />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">Topic</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" placeholder="topic of meeting" type="text" name="topic"
                                        value="<?php echo e(old('topic') ?? $data->topic); ?>" />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">Room</label>
                                <div class="col-sm-12 col-md-10">
                                    <select name="room_id" id="room" class="form-control">
                                        <option selected value="<?php echo e($data->room_id); ?>"><?php echo e($data->rooms->nama_ruang); ?>

                                        </option>
                                        <option disabled>-Select Room-</option>
                                        <?php $__currentLoopData = $room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($rowdata->id); ?>"><?php echo e($rowdata->nama_ruang); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">User</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" value="<?php echo e($data->user_id); ?>" name="user_id"
                                        type="hidden" />
                                    <input class="form-control" value="<?php echo e($data->user->name); ?>" type="text" disabled />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">Start Date</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" name="start_date" type="date"
                                        value="<?php echo e(old('start_date') ?? $data->start_date); ?>" />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">End Date</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" name="end_date" type="date"
                                        value="<?php echo e(old('end_date') ?? $data->end_date); ?>" />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">Start Time</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" placeholder="Select time" type="time" name="start_time"
                                        value="<?php echo e(old('start_time') ?? $data->start_time); ?>" />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">End Time</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" placeholder="Select time" type="time" name="end_time"
                                        value="<?php echo e(old('end_time') ?? $data->end_time); ?>" />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">Participants</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" placeholder="enter your participants" type="text"
                                        name="participants" value="<?php echo e(old('participants') ?? $data->activity); ?>" />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-12 col-md-2 col-form-label">Notes</label>
                                <div class="col-sm-12 col-md-10">
                                    <input class="form-control" placeholder="notes" type="text" name="note"
                                        value="<?php echo e(old('note') ?? $data->note); ?>" />
                                </div>
                            </div>
                            <div class="flex">
                                <button type="submit" class="btn btn-success">Update</button>
                                <button type="reset" class="btn btn-danger">Reset</button>
                                <a href="<?php echo e(route('app.dashboard')); ?>" class="btn btn-outline-warning">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('script'); ?>
        <script>
            $("#room").select2({
                responsive: true,
                width: '100%'
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/meetbookapp/resources/views/front/pages/agenda/edit.blade.php ENDPATH**/ ?>